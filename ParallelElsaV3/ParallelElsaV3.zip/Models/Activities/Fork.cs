﻿using ParallelElsaV3.Models;

namespace ParallelElsaV3.Models.Activities
{
    public class Fork : Node
    {
        public Fork(string text) : base(text)
        {

        }
    }
}

