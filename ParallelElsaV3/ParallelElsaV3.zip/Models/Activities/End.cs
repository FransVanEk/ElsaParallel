﻿namespace ParallelElsaV3.Models.Activities
{
    public class End : Node
    {
        public End(string text) : base(text)
        {

        }
    }
}

