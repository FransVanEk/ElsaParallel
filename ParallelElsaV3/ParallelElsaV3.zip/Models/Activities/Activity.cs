﻿namespace ParallelElsaV3.Models.Activities
{
    public class Activity : Node
    {
        public Activity(string text) : base(text)
        {

        }
    }
}

