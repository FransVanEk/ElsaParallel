﻿namespace ParallelElsaV3.Models.Activities
{
    public class Start : Node
    {
        public Start(string text) : base(text)
        {

        }
    }
}

