﻿namespace ParallelElsaV3.Engine
{
    public class ExecutionItems : List<ExecutionItem>
    {

    }
}